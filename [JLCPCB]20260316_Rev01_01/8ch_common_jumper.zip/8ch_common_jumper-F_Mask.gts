G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2026-03-16T12:56:02+09:00*
G04 #@! TF.ProjectId,8ch_common_jumper,3863685f-636f-46d6-9d6f-6e5f6a756d70,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2026-03-16 12:56:02*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10O,3.000000X9.000000*%
%ADD11O,1.900000X6.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X550000Y-21000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X0Y0D03*
X10160000Y0D03*
X20320000Y0D03*
X30480000Y0D03*
X42340000Y0D03*
X52500000Y0D03*
X62660000Y0D03*
X72820000Y0D03*
G04 #@! TD*
M02*
